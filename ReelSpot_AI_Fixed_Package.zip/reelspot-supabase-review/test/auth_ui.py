# UI test against a MOCK Supabase client (offline). Verifies the app's own auth/guard/credit logic, NOT the real Supabase service.
import threading, http.server, functools, json, sys
from playwright.sync_api import sync_playwright
MOCK = r"""
(function(){
 const L=JSON.parse(localStorage.getItem('mock_db')||'{"users":{},"used":{},"sess":null}');const save=()=>localStorage.setItem('mock_db',JSON.stringify(L));
 window.__confirmUser=e=>{L.users[e].confirmed=true;save()};let cb=null;const mk=u=>({user:{id:'u_'+u,email:u},access_token:'t'});
 const PLANS=[{id:'free',name:'Free Starter',price_inr:0,quota:2,lifetime:true},{id:'pro',name:'Creator Pro',price_inr:199,quota:20,lifetime:false},{id:'plus',name:'Creator Plus',price_inr:399,quota:50,lifetime:false}];
 const q=(data)=>{const o={select:()=>o,eq:()=>o,order:()=>o,limit:()=>o,single:()=>o,then:(f,r)=>Promise.resolve({data,error:null}).then(f,r)};return o};
 window.supabase={createClient:()=>({
  auth:{
   onAuthStateChange(f){cb=f;setTimeout(()=>f('INITIAL_SESSION',L.sess&&mk(L.sess)),20);return{data:{subscription:{}}}},
   async signUp({email,password}){if(window.__net)return{data:{},error:{name:'AuthRetryableFetchError',message:'Failed to fetch'}};
    if(L.users[email])return{data:{user:{identities:[]},session:null},error:null};
    L.users[email]={password,confirmed:!window.__confirm};save();
    if(window.__confirm)return{data:{user:{identities:[1]},session:null},error:null};
    L.sess=email;save();return{data:{user:mk(email).user,session:mk(email)},error:null}},
   async signInWithPassword({email,password}){const u=L.users[email];
    if(!u||u.password!==password)return{data:{},error:{code:'invalid_credentials',message:'Invalid login credentials'}};
    if(!u.confirmed)return{data:{},error:{code:'email_not_confirmed',message:'Email not confirmed'}};
    L.sess=email;save();setTimeout(()=>cb&&cb('SIGNED_IN',mk(email)),0);return{data:{user:mk(email).user,session:mk(email)},error:null}},
   async signOut(){L.sess=null;save();setTimeout(()=>cb&&cb('SIGNED_OUT',null),0);return{error:null}}},
  rpc(n){const u=L.sess;const used=(L.used[u]||0);return Promise.resolve({data:[{r_plan:'free',r_quota:2,r_used:used,r_left:Math.max(0,2-used),r_end:null}],error:null})},
  from(t){return t=='plans'?q(PLANS):t=='profiles'?q({email:L.sess,is_admin:false,created_at:'2026-10-16T00:00:00Z'}):q([])},
  functions:{async invoke(n,{body}){const u=L.sess;if(!u)return{data:null,error:{message:'x',context:{json:async()=>({error:'AUTH'})}}};
   if(window.__fail)return{data:null,error:{message:'x',context:{json:async()=>({error:'GENERATION_FAILED'})}}};
   if((L.used[u]||0)>=2)return{data:null,error:{message:'x',context:{json:async()=>({error:'NO_CREDITS'})}}};
   L.used[u]=(L.used[u]||0)+1;save();const left=2-L.used[u];
   const result=body.type=='ideas'?[1,2,3].map(i=>({title:'Idea '+i,hook:'h',story:'s',cat:'c',sound:'s',cam:'c',edit:'e',cap:'#x'})):'VIDEO: test plan';
   return{data:{result,credits:{r_plan:'free',r_quota:2,r_used:L.used[u],r_left:left,r_end:null}},error:null}}}
 })}
})();
"""
LEAFLET = r"""(function(){const m={setView(){return m},fitBounds(){},invalidateSize(){},removeLayer(){}};const c={addTo(){return c},bindPopup(){return c},on(){return c},clearLayers(){},setLatLng(){},setRadius(){}};
window.L={map:()=>m,tileLayer:()=>c,layerGroup:()=>c,marker:()=>c,circleMarker:()=>c,circle:()=>c,geoJSON:()=>c}})();"""
h = functools.partial(http.server.SimpleHTTPRequestHandler, directory='dist')
h.log_message = lambda *a, **k: None
srv = http.server.ThreadingHTTPServer(('127.0.0.1', 8765), h); threading.Thread(target=srv.serve_forever, daemon=True).start()
res = []
def check(name, ok, info=''):
    res.append(ok); print(('PASS ' if ok else 'FAIL ') + name + (' -> ' + str(info) if not ok else ''))
with sync_playwright() as p:
    b = p.chromium.launch(); ctx = b.new_context(viewport={'width': 360, 'height': 640}); pg = ctx.new_page()
    ctx.route('**/leaflet*.js', lambda r: r.fulfill(body=LEAFLET, content_type='application/javascript'))
    ctx.route('**/leaflet*.css', lambda r: r.fulfill(body='', content_type='text/css'))
    ctx.route('**/supabase*.js', lambda r: r.fulfill(body=MOCK, content_type='application/javascript'))
    ctx.route('**/qrcode*.js', lambda r: r.fulfill(body='', content_type='application/javascript'))
    errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
    dlg = []; pg.on('dialog', lambda d: (dlg.append(d.message), d.accept()))
    pg.goto('http://127.0.0.1:8765/'); pg.wait_for_timeout(300)
    vis = lambda i: pg.evaluate(f"document.getElementById('{i}').classList.contains('on')")
    chip = lambda: pg.inner_text('#cr')
    check('app loads without JS errors', not errs, errs)
    check('logged-out chip says Log in', chip() == 'Sign in' or 'in' in chip().lower(), chip())
    check('Discover works without account', vis('discover'))
    for tab, label in [('ideas', 'Ideas'), ('plan', 'Planner')]:
        pg.click(f'#n_{tab}'); pg.wait_for_timeout(100)
        check(f'protected page {label} redirects to auth', vis('auth') and 'log in' in pg.inner_text('#auth').lower())
    pg.click('#n_time'); check('Best Time is not blocked', vis('time'))
    pg.click('#n_ideas'); pg.click('text=Sign up')
    pg.fill('#em', 'bad'); pg.fill('#pw', 'password123'); pg.fill('#pw2', 'password123'); pg.click('#abtn')
    check('invalid email rejected', 'valid email' in pg.inner_text('#aerr'))
    pg.fill('#em', 'a@b.com'); pg.fill('#pw', 'short'); pg.fill('#pw2', 'short'); pg.click('#abtn')
    check('short password rejected', 'at least 8' in pg.inner_text('#aerr'))
    pg.fill('#pw', 'password123'); pg.fill('#pw2', 'different123'); pg.click('#abtn')
    check('mismatched passwords rejected', 'do not match' in pg.inner_text('#aerr'))
    pg.evaluate('window.__net=true'); pg.fill('#pw2', 'password123'); pg.click('#abtn'); pg.wait_for_timeout(100)
    check('network failure message', 'Network problem' in pg.inner_text('#aerr'), pg.inner_text('#aerr'))
    pg.evaluate('window.__net=false;window.__confirm=true'); pg.click('#abtn'); pg.wait_for_timeout(150)
    check('signup w/ email confirmation shows check-email message', 'Check your email' in pg.inner_text('#aerr'), pg.inner_text('#aerr'))
    pg.fill('#pw', 'password123'); pg.click('#abtn'); pg.wait_for_timeout(100)
    check('login before confirming is refused', 'confirm your email' in pg.inner_text('#aerr'), pg.inner_text('#aerr'))
    pg.evaluate("window.__confirmUser('a@b.com')")
    pg.fill('#pw', 'wrongpass1'); pg.click('#abtn'); pg.wait_for_timeout(100)
    check('wrong password message', 'Wrong email or password' in pg.inner_text('#aerr'))
    pg.fill('#pw', 'password123'); pg.click('#abtn'); pg.wait_for_timeout(300)
    check('login succeeds and returns to the page that was requested (Ideas)', vis('ideas'))
    check('chip shows remaining generations', '2 / 2' in chip(), chip())
    pg.click('#cr'); pg.wait_for_timeout(300)
    t = pg.inner_text('#pl')
    check('account card shows email, plan, remaining', 'a@b.com' in t and 'Free Starter' in t and '2 of 2' in t, t[:200])
    check('plans read from public.plans (prices shown from DB)', '₹199' in t and '₹399' in t and 'Showing default prices' not in t)
    pg.click('#n_ideas'); pg.wait_for_timeout(100)
    pg.evaluate('window.__fail=true'); pg.click('button:has-text("Generate My Next Reel")'); pg.wait_for_timeout(300)
    check('failed generation shows error and keeps credits', 'no credit was used' in ' '.join(dlg) and '2 / 2' in chip(), (dlg, chip()))
    pg.evaluate('window.__fail=false'); pg.click('button:has-text("Generate My Next Reel")'); pg.wait_for_timeout(300)
    check('successful generation consumes 1 credit', '1 / 2' in chip() and 'Idea 1' in pg.inner_text('#iout'), chip())
    pg.click('button:has-text("Generate My Next Reel")'); pg.wait_for_timeout(300)
    check('second success -> 0 left', '0 / 2' in chip(), chip())
    dlg.clear(); pg.click('button:has-text("Generate My Next Reel")'); pg.wait_for_timeout(400)
    check('third generation blocked by server and plans shown', vis('plans') and any('No generations left' in d for d in dlg), dlg)
    pg.reload(); pg.wait_for_timeout(500)
    check('session persists after reload with usage preserved', '0 / 2' in chip(), chip())
    pg.click('#n_ideas'); pg.wait_for_timeout(200)
    check('protected page opens after reload (session restored)', vis('ideas'))
    pg.click('#cr'); pg.wait_for_timeout(200); pg.click('text=Log out'); pg.wait_for_timeout(300)
    check('logout returns to Discover and shows logged-out state', vis('discover') and 'in' in chip().lower() and '/' not in chip(), chip())
    pg.click('#n_plan'); pg.wait_for_timeout(100)
    check('protected page blocked again after logout', vis('auth'))
    pg.click('text=Sign up'); pg.fill('#em', 'a@b.com'); pg.fill('#pw', 'password123'); pg.fill('#pw2', 'password123'); pg.click('#abtn'); pg.wait_for_timeout(150)
    check('duplicate email message', 'already registered' in pg.inner_text('#aerr'), pg.inner_text('#aerr'))
    pg.evaluate('window.__confirm=false'); pg.click('text=Sign up'); pg.fill('#em', 'new@user.com'); pg.fill('#pw', 'password123'); pg.fill('#pw2', 'password123'); pg.click('#abtn'); pg.wait_for_timeout(400)
    check('signup with instant session logs in, returns to requested page, fresh 2/2 credits', vis('plan') and '2 / 2' in chip(), chip())
    pg.click('#cr'); pg.click('text=Log out'); pg.wait_for_timeout(200); pg.click('#n_ideas'); pg.wait_for_timeout(100)
    check('no horizontal overflow on 360px screen (auth)', pg.evaluate('document.documentElement.scrollWidth<=window.innerWidth'))
    check('no JS errors during whole run', not errs, errs)
    b.close()
print(f'\n{sum(res)}/{len(res)} passed'); sys.exit(0 if all(res) else 1)
