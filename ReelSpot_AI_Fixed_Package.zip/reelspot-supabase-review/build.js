// Injects public Supabase settings from environment variables into reelspot.template.html -> dist/index.html
const fs = require('fs')
try { // optional local .env file
  for (const l of fs.readFileSync('.env', 'utf8').split(/\r?\n/)) {
    const m = l.match(/^\s*([A-Z_]+)\s*=\s*(.*?)\s*$/)
    if (m && !(m[1] in process.env)) process.env[m[1]] = m[2].replace(/^['"]|['"]$/g, '')
  }
} catch (_) {}
const url = (process.env.SUPABASE_URL || '').replace(/\/$/, ''), key = process.env.SUPABASE_PUBLISHABLE_KEY || ''
const die = m => { console.error('BUILD ERROR: ' + m); process.exit(1) }
if (!url || !key) die('Set SUPABASE_URL and SUPABASE_PUBLISHABLE_KEY (see .env.example).')
if (!/^https:\/\/[a-z0-9-]+\.supabase\.co$/.test(url)) die('SUPABASE_URL must look like https://<project-ref>.supabase.co')
if (/^sb_secret_/.test(key)) die('That is a SECRET key. Use the publishable key (sb_publishable_...).')
if (key.startsWith('eyJ')) { try { if (JSON.parse(Buffer.from(key.split('.')[1], 'base64url').toString()).role === 'service_role') die('That is a service-role key. Never use it in the browser.') } catch (_) {} }
const out = fs.readFileSync('reelspot.template.html', 'utf8').replace('__SUPABASE_URL__', url).replace('__SUPABASE_PUBLISHABLE_KEY__', key)
fs.mkdirSync('dist', { recursive: true }); fs.writeFileSync('dist/index.html', out)
console.log('Built dist/index.html for ' + url)
