# ReelSpot AI package status

This ZIP contains frontend/schema compatibility changes and a candidate migration. It is not an already deployed website.

## Included
- Static website source and Netlify build config
- Supabase auth UI
- Frontend plan query aligned to the existing `plans` table
- Account/admin lookup aligned to existing `profiles` and `admin_users`
- Candidate compatibility SQL for generation quota RPCs
- Original conflicting fresh-database migration retained under a `DO_NOT_RUN_...` name

## Not included / not yet live
- No real Netlify deployment
- No live Supabase Edge Function deployment
- No actual AI-provider integration; the current generation function returns template-generated content
- No owner-specific GPay QR or verified UPI payment process
- No successful end-to-end live auth/quota/payment test

Never put the Supabase service-role key in browser code. Review and test SQL in a separate project before applying to production.
