// Extract from reelspot.template.html (Supabase client initialisation + auth listener + plan loading).
// Placeholders are replaced at build time by build.js from environment variables.
const SB_URL='__SUPABASE_URL__',SB_KEY='__SUPABASE_PUBLISHABLE_KEY__'; // placeholders are replaced at build time from environment variables (see build.js). Publishable key only.
const PROT=['ideas','plan']; // pages that need a signed-in user (AI generation)
const cfg=!SB_URL.startsWith('__')&&!SB_KEY.startsWith('__')&&!!window.supabase;
const cfgMsg=()=>SB_URL.startsWith('__')||SB_KEY.startsWith('__')?'The app is not configured. Set SUPABASE_URL and SUPABASE_PUBLISHABLE_KEY and rebuild (see README).':'Could not load the Supabase library. Check your internet connection and reload.';
let sb=null,user=null,admin=false,CR=null,PROF=null,lerr='',ready=false,cur='discover',back=null,plansSrc='default',amode='login',abusy=false,anote='';
let resolveReady;const authReady=new Promise(r=>resolveReady=r);
function go(v){
 if(PROT.includes(v)){if(cfg&&!ready){authReady.then(()=>go(v));return}
  if(!user){back=v;anote=cfg?'Please log in to use this feature.':'';v='auth'}}
 if(v=='auth'&&user)v='plans';
 go0(v);cur=v;if(v=='auth')renderAuth()}
function chip(){go(cfg&&!user?'auth':'plans')}
if(cfg){sb=supabase.createClient(SB_URL,SB_KEY,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}});
 sb.auth.onAuthStateChange((ev,ses)=>{user=ses?ses.user:null;if(!ready){ready=true;resolveReady()}
  if(!user&&PROT.includes(cur))go('discover');setTimeout(refresh,0)});
 setTimeout(()=>{if(!ready){ready=true;resolveReady()}},4000);loadPlans()}else{ready=true;resolveReady()}
async function loadPlans(){try{const{data,error}=await sb.from('plans').select('id,name,price_inr,quota,lifetime');if(error||!data||!data.length)throw 0;
 data.forEach(x=>{PLANS[x.id]={n:x.name,p:x.price_inr,q:x.quota,t:x.lifetime?'lifetime':'month'}});plansSrc='server'}catch(e){plansSrc='default'}
 if($('plans').classList.contains('on'))renderPlans()}
