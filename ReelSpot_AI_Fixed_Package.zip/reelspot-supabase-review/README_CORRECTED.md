# ReelSpot AI — corrected review package

## Important status
This package is a **compatibility work-in-progress**, not a finished production app.
It preserves your existing database design and adds a candidate migration for generation limits.
It does not yet finish the GPay admin approval workflow or guarantee that the frontend and Edge Function are fully connected.

## Do not run the original migration
The file `supabase/migrations/DO_NOT_RUN_001_reelspot_fresh_database_only.sql` is kept only as reference.
It was designed for a brand-new database and conflicts with the schema you already have.
Do not rename it back or apply it to your existing project.

## Before using the compatibility migration
1. Make a database backup.
2. Test in a separate Supabase project first.
3. Inspect `supabase/migrations/002_reelspot_existing_schema_compatibility.sql`.
4. Confirm the actual values in `plans.billing_period` and `generation_events.status` match the assumptions in the SQL.
5. Apply only after review.

The compatibility migration expects your existing columns:
- `plans(code, generation_limit, billing_period, active)`
- `profiles(id)`
- `subscriptions(user_id, plan_code, status, current_period_start, current_period_end)`
- `generation_events(id, user_id, plan_code, status, request_id, created_at, completed_at)`

It creates server-only RPCs:
- `reelspot_credits_left`
- `reelspot_reserve_generation`
- `reelspot_finish_generation`

These are intended to be called by the Supabase Edge Function using the service-role client. Never expose the service-role key in the browser.

## Remaining work before launch
- Update `supabase/functions/generate/index.ts` to call the `reelspot_*` RPC names.
- Update frontend plan loading to query the existing `plans` columns (`code`, `name`, `price_inr`, `generation_limit`, `billing_period`).
- Implement payment submission and private admin approval using the existing `payment_orders`, `subscriptions`, and `admin_users` schema.
- Add a secure admin setup process after you create your own account.
- Configure `SUPABASE_URL`, `SUPABASE_PUBLISHABLE_KEY`, and Edge Function secrets in their proper environments.
- Test signup, login, failed generations, quota limits, duplicate payment approvals, and mobile UI.
- Restrict Edge Function CORS to the deployed website origin before production.

## GPay manual verification
A QR code and user-entered UPI reference are only a claim. An admin must compare the reference and amount against the real transaction record before approval. Do not activate a paid plan merely because a user uploads a screenshot.

## Local build
This project requires Node.js 18+.
1. Copy `.env.example` to `.env`.
2. Put the Supabase project URL and **publishable key only** in `.env`.
3. Run `npm install` if needed.
4. Run `npm start`.
5. Never place a service-role or secret key in `.env` used for the browser build.


## Integration updates in this package
- Frontend plan loading now uses the existing `plans.code`, `generation_limit`, and `billing_period` fields.
- Account refresh now checks the existing `profiles.display_name` and `admin_users` table rather than expecting nonexistent `profiles.email` / `profiles.is_admin`.
- Compatibility migration includes wrappers matching the existing Edge Function RPC names (`reserve_generation`, `finish_generation`, `credits_left`) and a `my_credits()` function for the logged-in user.
- These changes are not proof that the migration has been applied or that live generation has passed. Test the migration in a separate Supabase project first; inspect actual status constraints and indexes before production use.

## Still required for a real launch
- Apply and test the compatibility migration after reviewing it; it has not been applied automatically.
- Deploy the `generate` Edge Function and configure its environment secrets.
- Configure the frontend's Netlify environment variables.
- Implement the GPay QR and manual payment-review workflow; no live UPI QR or automatic payment verification is included because the owner's UPI ID/QR and admin account setup are not supplied.
- Test the quota rules with real authenticated test users and ensure a failed generation returns its reservation to an available allowance. Pending reservations older than two minutes are ignored by quota counting, but cleanup/recovery should still be added before production.

## Correction note (2026-10-16)
- Corrected payment-order frontend column names to match the inspected schema (`plan_code`, `upi_reference`).
- Removed the invalid `profiles(email)` relation from the admin query.
- Payment submission and admin approval are deliberately disabled in this build because the secure `submit_payment`, `approve_payment`, and `reject_payment` database RPCs are not implemented. Do not send real money or treat the displayed QR as a production payment flow.
- Static build and Node syntax checks passed with placeholder credentials. This does not mean Supabase auth, database RPCs, AI generation, or payments have been end-to-end tested.
