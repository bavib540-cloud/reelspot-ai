# Review notes

The original `001_reelspot.sql` is for a fresh database and must not be run against the existing project. It creates incompatible plans/profiles/payment/subscription/generation structures, duplicates the auth trigger, and contains broad schema-wide revokes. It has been renamed to `DO_NOT_RUN_001_reelspot_fresh_database_only.sql` to reduce accidental execution risk.

The new `002_reelspot_existing_schema_compatibility.sql` is a candidate migration for the existing schema, not production-certified. Review and test it separately before applying. The frontend and Edge Function still need to be aligned with the existing column names and new `reelspot_*` RPC names. GPay manual payment review is not yet implemented.
