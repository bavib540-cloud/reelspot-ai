// Minimal static server for local testing: serves ./dist on http://localhost:5173
const http = require('http'), fs = require('fs')
http.createServer((q, r) => { try { r.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); r.end(fs.readFileSync('dist/index.html')) } catch (e) { r.writeHead(500); r.end('Run: npm run build') } })
  .listen(process.env.PORT || 5173, () => console.log('ReelSpot AI on http://localhost:' + (process.env.PORT || 5173)))
