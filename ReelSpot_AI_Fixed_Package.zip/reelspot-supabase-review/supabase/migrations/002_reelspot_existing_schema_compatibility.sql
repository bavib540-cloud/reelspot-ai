-- ReelSpot AI: compatibility add-on for the EXISTING schema.
-- IMPORTANT: review this file and test in a separate Supabase project before applying.
-- This migration deliberately does NOT create/replace existing tables or auth triggers.
-- Assumed existing schema:
-- plans(code, price_inr, generation_limit, billing_period, active)
-- profiles(id), subscriptions(user_id, plan_code, status, current_period_start, current_period_end)
-- generation_events(user_id, plan_code, status, request_id, created_at, completed_at)
--
-- Backend-only RPCs. Edge Function should call these with the service-role client.
-- The service-role key must NEVER be included in browser code.

create or replace function public.reelspot_credits_left(p_uid uuid)
returns table(plan_code text, quota integer, used integer, remaining integer, period_end timestamptz)
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  v_plan text;
  v_quota integer;
  v_used integer;
  v_start timestamptz;
  v_end timestamptz;
  v_period text;
begin
  if p_uid is null then
    raise exception 'AUTH_REQUIRED';
  end if;

  select s.plan_code, s.current_period_start, s.current_period_end
    into v_plan, v_start, v_end
  from public.subscriptions s
  where s.user_id = p_uid
    and s.status = 'active'
    and s.current_period_start <= now()
    and s.current_period_end > now()
  order by s.current_period_end desc
  limit 1;

  if v_plan is null then
    v_plan := 'free_starter';
    v_start := null;
    v_end := null;
  end if;

  select p.generation_limit, p.billing_period
    into v_quota, v_period
  from public.plans p
  where p.code = v_plan and p.active = true;

  if v_quota is null then
    raise exception 'PLAN_NOT_CONFIGURED: %', v_plan;
  end if;

  if v_period = 'lifetime' or v_plan = 'free_starter' then
    select count(*)::integer into v_used
    from public.generation_events g
    where g.user_id = p_uid
      and g.plan_code = v_plan
      and (g.status = 'success'
        or (g.status = 'pending' and g.created_at > now() - interval '2 minutes'));
    return query select v_plan, v_quota, v_used, greatest(v_quota - v_used, 0), null::timestamptz;
  else
    select count(*)::integer into v_used
    from public.generation_events g
    where g.user_id = p_uid
      and g.plan_code = v_plan
      and g.created_at >= coalesce(v_start, now() - interval '1 month')
      and g.created_at < coalesce(v_end, now() + interval '1 second')
      and (g.status = 'success'
        or (g.status = 'pending' and g.created_at > now() - interval '2 minutes'));
    return query select v_plan, v_quota, v_used, greatest(v_quota - v_used, 0), v_end;
  end if;
end;
$$;

create or replace function public.reelspot_reserve_generation(p_uid uuid, p_kind text)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_credit record;
  v_id uuid;
begin
  if p_uid is null then raise exception 'AUTH_REQUIRED'; end if;
  if p_kind not in ('ideas', 'plan') then raise exception 'BAD_KIND'; end if;

  -- Serialise generation reservations for the same user.
  perform 1 from public.profiles p where p.id = p_uid for update;
  if not found then raise exception 'PROFILE_NOT_FOUND'; end if;

  select * into v_credit from public.reelspot_credits_left(p_uid);
  if coalesce(v_credit.remaining, 0) < 1 then raise exception 'NO_CREDITS'; end if;

  insert into public.generation_events(user_id, plan_code, status, request_id)
  values (p_uid, v_credit.plan_code, 'pending', gen_random_uuid())
  returning id into v_id;

  return v_id;
end;
$$;

create or replace function public.reelspot_finish_generation(p_id uuid, p_ok boolean)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  if p_id is null then raise exception 'BAD_REQUEST'; end if;

  update public.generation_events
  set status = case when p_ok then 'success' else 'failed' end,
      completed_at = now()
  where id = p_id and status = 'pending';

  if not found then
    raise exception 'GENERATION_NOT_PENDING';
  end if;
end;
$$;

-- Keep these RPCs server-only. Do not grant them to anon/authenticated clients.
revoke all on function public.reelspot_credits_left(uuid) from public, anon, authenticated;
revoke all on function public.reelspot_reserve_generation(uuid, text) from public, anon, authenticated;
revoke all on function public.reelspot_finish_generation(uuid, boolean) from public, anon, authenticated;
grant execute on function public.reelspot_credits_left(uuid) to service_role;
grant execute on function public.reelspot_reserve_generation(uuid, text) to service_role;
grant execute on function public.reelspot_finish_generation(uuid, boolean) to service_role;


-- Compatibility wrappers used by the existing browser and Edge Function.
-- `my_credits` is deliberately callable only from the authenticated user's
-- backend/service-role flow; the browser should not be allowed to choose p_uid.
create or replace function public.my_credits()
returns table(plan_code text, r_quota integer, r_used integer, r_left integer, period_end timestamptz)
language plpgsql
stable
security definer
set search_path = ''
as $$
declare v_uid uuid;
begin
  v_uid := auth.uid();
  if v_uid is null then raise exception 'AUTH_REQUIRED'; end if;
  return query
    select c.plan_code, c.quota, c.used, c.remaining, c.period_end
    from public.reelspot_credits_left(v_uid) c;
end;
$$;

create or replace function public.credits_left(p_uid uuid)
returns table(plan_code text, r_quota integer, r_used integer, r_left integer, period_end timestamptz)
language sql
stable
security definer
set search_path = ''
as $$
  select c.plan_code, c.quota, c.used, c.remaining, c.period_end
  from public.reelspot_credits_left(p_uid) c;
$$;

create or replace function public.reserve_generation(p_uid uuid, p_kind text)
returns uuid
language sql
security definer
set search_path = ''
as $$
  select public.reelspot_reserve_generation(p_uid, p_kind);
$$;

create or replace function public.finish_generation(p_id uuid, p_ok boolean)
returns void
language sql
security definer
set search_path = ''
as $$
  select public.reelspot_finish_generation(p_id, p_ok);
$$;

revoke all on function public.my_credits() from public, anon;
revoke all on function public.credits_left(uuid) from public, anon, authenticated;
revoke all on function public.reserve_generation(uuid, text) from public, anon, authenticated;
revoke all on function public.finish_generation(uuid, boolean) from public, anon, authenticated;
grant execute on function public.my_credits() to authenticated;
grant execute on function public.credits_left(uuid) to service_role;
grant execute on function public.reserve_generation(uuid, text) to service_role;
grant execute on function public.finish_generation(uuid, boolean) to service_role;
