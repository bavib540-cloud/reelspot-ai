-- !!! REVIEW STATUS: written for a FRESH database. DO NOT RUN on a project that already has
-- !!! profiles / plans / subscriptions / payment_orders / credit_ledger (see REVIEW_CONFLICTS.md).
-- !!! Lines near the end ("revoke ... on all tables/functions in schema public") affect EVERY object in public.
-- ReelSpot AI: profiles, plans, subscriptions, usage, payments, credit history + RLS
create extension if not exists pgcrypto;

create table public.plans(id text primary key, name text not null, price_inr int not null, quota int not null, lifetime boolean not null default false);
insert into public.plans values ('free','Free Starter',0,2,true),('pro','Creator Pro',199,20,false),('plus','Creator Plus',399,50,false);

create table public.profiles(id uuid primary key references auth.users on delete cascade, email text, is_admin boolean not null default false, created_at timestamptz not null default now());

create table public.payment_orders(
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.profiles(id) on delete cascade,
 plan_id text not null references public.plans(id),
 amount_inr int not null,
 utr text not null unique check (utr ~ '^[0-9]{12}$'),
 status text not null default 'pending' check (status in ('pending','approved','rejected')),
 reviewed_by uuid, reviewed_at timestamptz, created_at timestamptz not null default now());

create table public.subscriptions(
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.profiles(id) on delete cascade,
 plan_id text not null references public.plans(id),
 period_start timestamptz not null, period_end timestamptz not null,
 status text not null default 'active' check (status in ('active','cancelled','expired')),
 order_id uuid unique references public.payment_orders(id),
 created_at timestamptz not null default now());

create table public.generations(
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.profiles(id) on delete cascade,
 kind text not null check (kind in ('ideas','plan')),
 plan_id text not null references public.plans(id),
 status text not null default 'pending' check (status in ('pending','success','failed')),
 created_at timestamptz not null default now());
create index on public.generations(user_id, created_at);

create table public.credit_ledger(id bigint generated always as identity primary key, user_id uuid not null references public.profiles(id) on delete cascade, delta int not null, reason text not null, ref uuid, created_at timestamptz not null default now());

-- new user => profile + 2 lifetime free credits (logged)
create function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin
 insert into profiles(id,email) values(new.id,new.email);
 insert into credit_ledger(user_id,delta,reason) values(new.id,2,'free_signup');
 return new;
end$$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

create function public.is_admin() returns boolean language sql stable security definer set search_path=public as
$$ select coalesce((select is_admin from profiles where id=auth.uid()),false) $$;

-- credit calculation (counts successful + very recent pending generations)
create function public.credits_left(p_uid uuid) returns table(r_plan text, r_quota int, r_used int, r_left int, r_end timestamptz)
language plpgsql stable security definer set search_path=public as $$
declare s subscriptions%rowtype; q int; u int;
begin
 select * into s from subscriptions x where x.user_id=p_uid and x.status='active' and x.period_start<=now() and x.period_end>now() order by x.period_end desc limit 1;
 if found then
  select p.quota into q from plans p where p.id=s.plan_id;
  select count(*) into u from generations g where g.user_id=p_uid and g.plan_id=s.plan_id and g.created_at>=s.period_start and g.created_at<s.period_end
    and (g.status='success' or (g.status='pending' and g.created_at>now()-interval '2 minutes'));
  return query select s.plan_id,q,u,greatest(q-u,0),s.period_end;
 else
  select p.quota into q from plans p where p.id='free';
  select count(*) into u from generations g where g.user_id=p_uid and g.plan_id='free'
    and (g.status='success' or (g.status='pending' and g.created_at>now()-interval '2 minutes'));
  return query select 'free'::text,q,u,greatest(q-u,0),null::timestamptz;
 end if;
end$$;

create function public.my_credits() returns table(r_plan text, r_quota int, r_used int, r_left int, r_end timestamptz)
language sql stable security definer set search_path=public as $$ select * from credits_left(auth.uid()) $$;

-- server-only: atomically reserve one generation (locks the user row to stop races)
create function public.reserve_generation(p_uid uuid, p_kind text) returns uuid language plpgsql security definer set search_path=public as $$
declare c record; gid uuid;
begin
 perform 1 from profiles where id=p_uid for update;
 select * into c from credits_left(p_uid);
 if c.r_left<1 then raise exception 'NO_CREDITS'; end if;
 insert into generations(user_id,kind,plan_id) values(p_uid,p_kind,c.r_plan) returning id into gid;
 return gid;
end$$;

-- server-only: success consumes the credit, failure releases it
create function public.finish_generation(p_id uuid, p_ok boolean) returns void language plpgsql security definer set search_path=public as $$
declare uid uuid;
begin
 update generations set status=case when p_ok then 'success' else 'failed' end where id=p_id and status='pending' returning user_id into uid;
 if found and p_ok then insert into credit_ledger(user_id,delta,reason,ref) values(uid,-1,'generation',p_id); end if;
end$$;

-- user submits a payment claim; amount comes from the plans table, never from the client
create function public.submit_payment(p_plan text, p_utr text) returns uuid language plpgsql security definer set search_path=public as $$
declare pr plans%rowtype; oid uuid;
begin
 if auth.uid() is null then raise exception 'AUTH'; end if;
 select * into pr from plans where id=p_plan and not lifetime;
 if not found then raise exception 'BAD_PLAN'; end if;
 insert into payment_orders(user_id,plan_id,amount_inr,utr) values(auth.uid(),p_plan,pr.price_inr,p_utr) returning id into oid;
 return oid;
end$$;

-- admin only; row lock + status check + unique(order_id) make double approval impossible
create function public.approve_payment(p_order uuid) returns void language plpgsql security definer set search_path=public as $$
declare o payment_orders%rowtype; st timestamptz;
begin
 if not is_admin() then raise exception 'FORBIDDEN'; end if;
 select * into o from payment_orders where id=p_order for update;
 if not found then raise exception 'NOT_FOUND'; end if;
 if o.status<>'pending' then raise exception 'ALREADY_PROCESSED'; end if;
 select greatest(now(), coalesce(max(period_end),now())) into st from subscriptions where user_id=o.user_id and status='active' and period_end>now();
 insert into subscriptions(user_id,plan_id,period_start,period_end,order_id) values(o.user_id,o.plan_id,st,st+interval '1 month',o.id);
 update payment_orders set status='approved',reviewed_by=auth.uid(),reviewed_at=now() where id=o.id;
 insert into credit_ledger(user_id,delta,reason,ref) values(o.user_id,(select quota from plans where id=o.plan_id),'purchase',o.id);
end$$;

create function public.reject_payment(p_order uuid) returns void language plpgsql security definer set search_path=public as $$
begin
 if not is_admin() then raise exception 'FORBIDDEN'; end if;
 update payment_orders set status='rejected',reviewed_by=auth.uid(),reviewed_at=now() where id=p_order and status='pending';
 if not found then raise exception 'ALREADY_PROCESSED'; end if;
end$$;

-- RLS: users read only their own rows; all writes go through the functions above
alter table plans enable row level security; alter table profiles enable row level security; alter table payment_orders enable row level security;
alter table subscriptions enable row level security; alter table generations enable row level security; alter table credit_ledger enable row level security;
create policy plans_read on plans for select using (true);
create policy profiles_read on profiles for select using (id=auth.uid() or is_admin());
create policy orders_read on payment_orders for select using (user_id=auth.uid() or is_admin());
create policy subs_read on subscriptions for select using (user_id=auth.uid() or is_admin());
create policy gens_read on generations for select using (user_id=auth.uid());
create policy ledger_read on credit_ledger for select using (user_id=auth.uid());

revoke all on all tables in schema public from anon, authenticated;
grant select on plans to anon, authenticated;
grant select on profiles, payment_orders, subscriptions, generations, credit_ledger to authenticated;

revoke execute on all functions in schema public from public, anon, authenticated;
grant execute on function public.my_credits(), public.submit_payment(text,text), public.approve_payment(uuid), public.reject_payment(uuid) to authenticated;
grant execute on function public.credits_left(uuid), public.reserve_generation(uuid,text), public.finish_generation(uuid,boolean) to service_role;
-- is_admin() is used inside RLS policies, so authenticated needs it:
grant execute on function public.is_admin() to authenticated;
-- After signing up, make yourself admin (run once, SQL editor): update public.profiles set is_admin=true where email='YOUR_EMAIL';
