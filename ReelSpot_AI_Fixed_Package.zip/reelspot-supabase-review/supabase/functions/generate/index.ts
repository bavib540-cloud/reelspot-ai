// Supabase Edge Function: authenticates the user, reserves a credit atomically, generates, then confirms or releases the credit.
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.4'
const cors = { 'Access-Control-Allow-Origin': Deno.env.get('ALLOWED_ORIGIN') ?? '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type' }
const J = (b: unknown, s = 200) => new Response(JSON.stringify(b), { status: s, headers: { ...cors, 'Content-Type': 'application/json' } })
const str = (x: unknown, m = 80) => String(x ?? '').slice(0, m)
const MOODS = ['scary','cinematic','funny','mysterious','emotional','aesthetic','educational']
const H: Record<string,string[]> = {scary:['Never open that door at midnight…','நள்ளிரவில் கதவைத் திறக்காதே!'],cinematic:['One shot. One story. Watch till the end.','ஒரே ஷாட். ஒரு கதை. கடைசி வரை பாருங்கள்.'],funny:["I tried this so you don't have to 😂",'நான் பண்ணிப் பார்த்தேன் — நீங்க பண்ணாதீங்க 😂'],mysterious:['Who left this here?','இதை இங்கே வைத்தது யார்?'],emotional:['Some goodbyes arrive without a word.','சில பிரிவுகள் வார்த்தையின்றி வரும்.'],aesthetic:['POV: your perfect golden hour.','உங்கள் பொன்மாலை நேரம்.'],educational:['3 things nobody tells you about this place.','இந்த இடத்தைப் பற்றி யாரும் சொல்லாத 3 விஷயங்கள்.']}
const MU: Record<string,string> = {scary:'low drones, wind, sudden hit',cinematic:'slow orchestral build',funny:'quirky upbeat + comic SFX',mysterious:'sparse piano, ticking',emotional:'soft piano/strings',aesthetic:'lo-fi chill',educational:'light neutral beat'}
const SC: Record<string,string[]> = {scary:['Establish the quiet place; slowly move toward the focal point (door/path).','Character notices something odd at the edge of frame.','Character hesitates; sound cues build suspense.','Something unseen moves; slow push-in.','Sudden reveal, then hold a tense final frame.'],cinematic:['Wide establishing shot of {l}.','Medium shot: subject enters frame.','Close detail shots (hands, textures).','Hero movement shot following the subject.','Pull back to a wide closing frame.'],funny:['Set up the situation with a straight face.','First small mishap.','Escalation — reaction close-up.','Peak absurd moment.','Punchline cut and freeze-frame.'],mysterious:['Object/clue shown in frame.','Subject investigates.','Second clue reveals a pattern.','Reframe: what we assumed was wrong.','Open-ended final shot.'],emotional:['Quiet wide shot, subject alone.','Close-up of a meaningful object.','Memory-like slow movement.','Subject reacts, eyes to camera/away.','Slow fade on final frame.'],aesthetic:['Light and textures at {l}.','Subject walking, shallow focus.','Detail inserts.','Slow-motion movement.','Wide silhouette finish.'],educational:['Hook: state the surprising fact.','Fact 1 with visual proof.','Fact 2 on location.','Fact 3 / demonstration.','Recap + call to follow.']}
const CAMS = ['slow push-in','handheld follow','low angle','over-shoulder','static wide','tilt up']

function ideas(p: any) {
  const g = str(p.g), m = p.m, d = +p.d, n = +p.n, l = str(p.l) || 'a public location', lg = str(p.lg, 30), e = str(p.e, 20), ta = lg === 'Tamil'
  const hk = H[m][ta ? 1 : 0]
  const cam = e === 'phone only' ? 'handheld walk-in, slow push' : e === 'tripod' ? 'locked-off frame + slow pan' : 'shallow-depth dolly/slider push'
  const T = [['The Rule','a character breaks a simple rule and the place reacts'],['The Reveal','a slow build ending in one surprising visual'],['The Loop','the ending flows back into the first frame']]
  return T.map((t, i) => ({ title: `${g} Reel — ${t[0]}`, hook: hk, story: `${d}s ${m} ${g.toLowerCase()} at ${l}: ${t[1]}. ${n} ${n > 1 ? 'people' : 'person'}.`,
    cat: g === 'Horror' ? 'Horror atmosphere (permitted, safe, with a companion)' : g === 'Sunset' ? 'Cinematic landscapes / waterfronts' : 'Gardens, streets or cafes',
    sound: MU[m], cam, edit: ['match cuts on movement','speed ramp on the reveal','subtitles for ' + lg][i],
    cap: `${hk} #reels #${g.split(' ')[0].toLowerCase()} #${m} #${ta ? 'tamilreels' : 'shortfilm'}`, g, d, l, m, lg }))
}

function plan(p: any) {
  const g = str(p.g), d = +p.d, l = str(p.l) || 'your location', m = p.m, e = str(p.e, 20), n = +p.n, ta = p.lg === 'Tamil', tm = str(p.pt, 30)
  const w = [.15,.2,.25,.25,.15]; let t = 0
  const night = /pm|night/i.test(tm)
  const sc = SC[m].map((s, i) => { const dd = Math.round(d * w[i]), a = t; t += dd
    return `Scene ${i+1} — ${a}–${i === 4 ? d : t}s: ${s.replace('{l}', l)}\n  Camera: ${CAMS[i % 6]} (${e}) | Light: ${tm || 'available light'} — ${night ? 'low practical light, no dangerous dark areas' : 'soft natural light'}\n  Sound: ${MU[m]} | Transition: ${['hard cut','whip','match cut','dip to black','smash cut'][i]}` }).join('\n\n')
  return `VIDEO: ${g} Reel — ${str(p.pi, 120) || 'Untitled'}\nDuration: ${d}s | Location: ${l} | People: ${n} | Equipment: ${e}\nHook: ${H[m][ta ? 1 : 0]}\nOn-screen text: "${H[m][ta ? 1 : 0]}"\n${ta ? 'Voice-over/dialogue: Tamil, short lines.' : 'Voice-over: optional.'}\n\n${sc}\n\nFILMING CHECKLIST\n[ ] Permission/access confirmed for ${l}\n[ ] Go with a companion; avoid isolated or restricted areas\n[ ] Battery, storage, clean lens\n[ ] Shoot each scene 2 takes + B-roll\n\nEDITING CHECKLIST\n[ ] Trim to ${d}s\n[ ] Add music (${MU[m]}) and SFX\n[ ] Captions/subtitles${ta ? ' in Tamil' : ''}\n[ ] Colour grade + export 9:16`
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors })
  const url = Deno.env.get('SUPABASE_URL')!
  const uc = createClient(url, Deno.env.get('SUPABASE_ANON_KEY')!, { global: { headers: { Authorization: req.headers.get('Authorization') ?? '' } } })
  const { data: { user } } = await uc.auth.getUser()
  if (!user) return J({ error: 'AUTH' }, 401)
  let body: any; try { body = await req.json() } catch { return J({ error: 'BAD_REQUEST' }, 400) }
  const t = body.type, p = body.p || {}
  if (t !== 'ideas' && t !== 'plan') return J({ error: 'BAD_TYPE' }, 400)
  if (!(+p.n >= 1 && +p.n <= 50) || !(+p.d >= 5 && +p.d <= 120) || !MOODS.includes(p.m)) return J({ error: 'BAD_INPUT' }, 400)
  const ad = createClient(url, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!)
  const r = await ad.rpc('reserve_generation', { p_uid: user.id, p_kind: t })
  if (r.error) return r.error.message.includes('NO_CREDITS') ? J({ error: 'NO_CREDITS' }, 402) : J({ error: 'SERVER' }, 500)
  try {
    const result = t === 'ideas' ? ideas(p) : plan(p)
    await ad.rpc('finish_generation', { p_id: r.data, p_ok: true })
    const c = await ad.rpc('credits_left', { p_uid: user.id })
    return J({ result, credits: c.data?.[0] })
  } catch (_e) {
    await ad.rpc('finish_generation', { p_id: r.data, p_ok: false })
    return J({ error: 'GENERATION_FAILED' }, 500)
  }
})
