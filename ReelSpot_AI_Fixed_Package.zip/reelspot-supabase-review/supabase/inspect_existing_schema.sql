-- READ-ONLY schema inspection. Contains SELECT statements only; changes nothing.
-- Run in Supabase SQL Editor, export each result (names/definitions only, no personal data) for review.

-- 1. Columns of the relevant tables
select table_name, ordinal_position, column_name, data_type, is_nullable, column_default
from information_schema.columns
where table_schema='public' and table_name in ('profiles','plans','subscriptions','generation_events','generations','payment_orders','credit_ledger','admin_users')
order by table_name, ordinal_position;

-- 2. Constraints (PK / UNIQUE / FK / CHECK)
select conrelid::regclass as tbl, conname, pg_get_constraintdef(oid) as definition
from pg_constraint where connamespace='public'::regnamespace order by 1,2;

-- 3. RLS status and policies
select tablename, rowsecurity from pg_tables where schemaname='public' order by 1;
select tablename, policyname, cmd, roles, qual, with_check from pg_policies where schemaname='public' order by 1,2;

-- 4. Triggers (auth.users and public tables)
select tgrelid::regclass as tbl, tgname, pg_get_triggerdef(oid) as definition
from pg_trigger where not tgisinternal and (tgrelid='auth.users'::regclass or tgrelid::regclass::text like 'public.%') order by 1,2;

-- 5. Functions in public (name, args, security definer?)
select p.proname, pg_get_function_identity_arguments(p.oid) as args, p.prosecdef as security_definer
from pg_proc p where p.pronamespace='public'::regnamespace order by 1;

-- 6. Table privileges for API roles
select table_name, grantee, string_agg(privilege_type, ', ' order by privilege_type) as privileges
from information_schema.role_table_grants where table_schema='public' and grantee in ('anon','authenticated') group by 1,2 order by 1,2;

-- 7. Approximate row counts only
select relname as tbl, n_live_tup as approx_rows from pg_stat_user_tables where schemaname='public' order by 1;
